
from flask import Flask, render_template, request, redirect, session, flash
from flask_bcrypt import Bcrypt 
from mysqlconnection import connectToMySQL
import re
app = Flask(__name__, static_url_path='/static')
app = Flask(__name__)
app.secret_key = "this s@*t is safe"
EMAIL_REGEX = re.compile(r'^[a-zA-Z0-9.+_-]+@[a-zA-Z0-9._-]+\.[a-zA-Z]+$')
INVALID_PASSWORD_REGEX = re.compile(r'^([^0-9]*|[^A-Z]*)$')
bcrypt = Bcrypt(app)

@app.route("/")
def index():
    db = connectToMySQL('my_udb')
    results = db.query_db('SELECT * FROM users')
    print(results)
    return render_template('index.html')
    # return render_template("index.html", all_users = results) #display registered info

@app.route('/success')
def success():
    if 'user_id' not in session:
        return redirect('/')
    else:
        db = connectToMySQL('my_udb')
        query = "SELECT * FROM users WHERE id=%(user_id)s;"
        data = {
            "user_id": session['user_id']
        }
        
        users = db.query_db(query, data)
        user =  users[0]

        print(users)

    db = connectToMySQL("my_udb")
    query = "SELECT  tweets.user_id as author_id, tweets.id as tweet_id, users.email, users.first_name, tweets.tweet, tweets.created_at FROM users JOIN tweets ON users.id = tweets.user_id ORDER BY tweets.created_at DESC;"
    my_feed = db.query_db(query)
    print("$" * 60)
    print(my_feed)

    db = connectToMySQL("my_udb")
    query = "SELECT tweet_id, COUNT(*) AS lm FROM likes Group By tweet_id;"
    like_count = db.query_db(query)
    print("!" * 90)
    print(like_count)


    return render_template("success.html", users=users[0], some_tweets=my_feed, num_likes=like_count)

@app.route("/create_tweet", methods=["POST"])
def add_tweet_to_db():
    is_valid = True

    if len(request.form['usertweet']) > 255:
        is_valid = False
        flash('Your tweet is too long. Just send two insteat :)')

    if len(request.form['usertweet']) < 1:
        flash('Tweet can NOT be empty!')
    else:
        db = connectToMySQL("my_udb")
        query = "INSERT INTO tweets (tweet, created_at, updated_at, user_id) VALUES (%(usertweet)s, NOW(), NOW(),%(user_id)s);"
        data = {
            "usertweet": request.form["usertweet"],
            "user_id": session['user_id']
        }
        
        db.query_db(query,data)
        print("*" * 50)
    return redirect("/success")


@app.route("/user", methods=["POST"])
def add_user_to_db():
    is_valid = True
    
    
    validate_email_query = 'SELECT id FROM users WHERE email=%(em)s;'
    data = {
        'em': request.form['email']
    }
    db = connectToMySQL('my_udb')
    existing_users = db.query_db(validate_email_query, data)

    
    if len(request.form['fname']) < 1:
        is_valid = False
        session['first_name']= request.form['fname']
        flash("Please enter a first name")

    if len(request.form['lname']) < 1:
        is_valid = False
        flash("Please enter a last name")

    if not EMAIL_REGEX.match(request.form['email']):
        is_valid = False    # test whether a field matches the pattern
        flash("Invalid email address!")

    if INVALID_PASSWORD_REGEX.match(request.form['pass']):
        flash("Password must have at least one uppercase character and at least one number")
        is_valid = False

    if len(request.form['pass']) < 5:
        is_valid = False
        flash("Please enter a valid password")

    if request.form['conpas'] != request.form['pass']: 
        is_valid = False
        flash("Please reenter a valid password!")

    if existing_users:
        flash("Email already in use")
        is_valid = False
    
    if not is_valid:
        return redirect('/')

    # if is_valid:
    pw_hash = bcrypt.generate_password_hash(request.form['pass'])  
    print(pw_hash)
    db = connectToMySQL("my_udb")  
    query = "INSERT INTO users (first_name, last_name, email, pw_hash, created_at, updated_at) VALUES (%(fn)s, %(ln)s, %(em)s, %(pw)s, NOW(), NOW());"
    data = {
        'fn': request.form['fname'],
        'ln': request.form['lname'],
        'em': request.form['email'],
        'pw': pw_hash    
    }
    
    session['user_id'] = db.query_db(query,data)

    # db = connectToMySQL("my_udb")
    # query2 = "SELECT * FROM users WHERE email = %(loginemail)s;"
    # data2 = {"loginemail": request.form['email']}
    # result = db.query_db(query2, data2)
    # session['user_id'] = result[0]['id']
    
    flash("Successfully added user to database!")
    
    return redirect("/success")

@app.route('/login', methods=['POST'])
def login():
    db = connectToMySQL('my_udb')
    query = "SELECT * FROM users WHERE email=%(loginemail)s;"
    data = {
        'loginemail': request.form['loginemail']
    }
    result = db.query_db(query, data)
    print("*" * 50)
    print(result)
    print("*" * 50)
    if result:
    #     user = existing_users[0]
        if bcrypt.check_password_hash(result[0]['pw_hash'], request.form['loginpassword']):
            session['user_id'] = result[0]['id']
            # flash
            session['login'] = True
            print(session)
            return redirect('/success')
    flash("Inncorrect username or password!")
    return redirect('/')

@app.route("/tweets/<tweet_id>/delete")
def delete_tweet(tweet_id):
    db = connectToMySQL('my_udb')
    query = "DELETE FROM likes WHERE tweet_id = %(t_id)s"      #this deletes all likes first before deleting tweet
    data = {
        "t_id": tweet_id,
        "u_id": session['user_id']
    }
    db.query_db(query,data)
    print("*&" * 50)    
    
    db = connectToMySQL('my_udb')
    query = "DELETE FROM tweets WHERE id = %(t_id)s AND user_id = %(u_id)s"
    data = {
        "t_id": tweet_id,
        "u_id": session['user_id']
    }
    db.query_db(query,data)
    print("*" * 50)

    return redirect("/success")

@app.route("/tweets/<tweet_id>/unlike")
def unlike_tweet(tweet_id):
    db = connectToMySQL('my_udb')
    query = "DELETE FROM likes WHERE tweet_id = %(l_id)s AND user_id = %(u_id)s"
    data = {
        "l_id": tweet_id,
        "u_id": session['user_id']
    }
    db.query_db(query,data)
    print("*" * 50)
    print(data)
    return redirect("/tweets/" + tweet_id + "/edit")

@app.route("/tweets/<tweet_id>/like", methods=['POST'])
def add_like(tweet_id):
    
    db = connectToMySQL("my_udb")
    query = "INSERT INTO likes (tweet_id, created_at, updated_at, user_id) VALUES (%(t_id)s, NOW(), NOW(),%(user_id)s);"
    data = {
        "t_id": tweet_id,
        "user_id": session['user_id']
    }
    
    db.query_db(query,data)
    print("*" * 50)
    print(data)

    return redirect("/success")
            
    
    

@app.route("/tweets/<tweet_id>/edit")
def edit_tweet(tweet_id):
    # db = connectToMySQL("my_udb")
    # query = "SELECT  tweets.user_id as author_id, tweets.id as tweet_id, users.email, users.first_name, tweets.tweet, tweets.created_at FROM users JOIN tweets ON users.id = tweets.user_id ORDER BY tweets.created_at DESC;"
    # likes_feed = db.query_db(query)
    # print("$" * 60)
    # print(likes_feed)
    

    db = connectToMySQL('my_udb')
    query = "SELECT  tweets.user_id, tweets.id, users.email, users.first_name, tweets.tweet, tweets.created_at FROM users JOIN tweets ON users.id = tweets.user_id WHERE tweets.id = %(t_id)s"
    data = {
        "t_id": tweet_id,
        "user_id": session['user_id']
        
    }
    user = db.query_db(query,data)
    print("*" * 50)
    print(user)

    db = connectToMySQL('my_udb')
    query = "SELECT users.first_name, users.email, users.last_name, users.id, likes.tweet_id  FROM users JOIN likes ON users.id = likes.user_id WHERE likes.tweet_id = %(tw_id)s;"
    data = {
        "tw_id": tweet_id,
        "user_id": session['user_id']
    }
    likes = db.query_db(query,data)


    return render_template("edit.html", user=user[0], some_tweets=user, users=likes)

@app.route("/tweets/<tweet_id>/update", methods=['POST'])
def update_tweet(tweet_id):

    is_valid = True

    if len(request.form['usertweet']) > 255:
        is_valid = False
        flash('Woah, your tweet is too long!')
        return redirect("/tweets/" + tweet_id + "/edit")
        
    if len(request.form['usertweet']) < 1:
        is_valid = False
        flash('Woah, your tweet is too short!')
        return redirect("/tweets/" + tweet_id + "/edit")
        
        
    
    db = connectToMySQL('my_udb')
    query = "UPDATE tweets SET tweet = %(myt)s WHERE id = %(t_id)s"
    data = {
        "t_id": tweet_id,
        "myt": request.form['usertweet'],

    }
    result = db.query_db(query,data)
    print("*$" * 90)
    print(request.form['usertweet'])
    return redirect("/success")

@app.route('/users')
def user_list():
    
    db = connectToMySQL('my_udb')
    query = "SELECT * FROM users Where id = %(id)s"
    data = {'id': id}
    results = db.query_db(query, data)
    print("^^" * 90)
    return render_template("/users", users=results)

# @app.route('/user/stats<user_id>')
# def idea_status(user_id):
#     db = connectToMySQL('my_udb')
#     query = "INSERT INTO followers(follower, following) VALUES (%(follower)s, %(followed)s)"
#     data = {
#         'follower': session['user_id'],
#         'followed': user_id
#     }
#     db.query_db(query,data)
#     return redirect('/success')





@app.route('/logout')
def logout():
    session.clear()
    return redirect('/')

if __name__ == "__main__":
    app.run(debug=True)
